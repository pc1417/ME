package com.example.demo;

public class Phone {
	
	private int id;
	private String phonename;
	private String color;
	private String memory;
	private int price;
	private int noofphone;
	
	public Phone(int id, String phonename, String color, String memory, int price, int noofphone) {
		super();
		this.id = id;
		this.phonename = phonename;
		this.color = color;
		this.memory = memory;
		this.price = price;
		this.noofphone = noofphone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getphonename() {
		return phonename;
	}

	public void setphonename(String phonename) {
		this.phonename = phonename;
	}
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public String getMemory() {
		return memory;
	}

	public void setMemory(String memory) {
		this.memory = memory;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getnoofphone() {
		return noofphone;
	}

	public void setnoofphone(int noofphone) {
		this.noofphone = noofphone;
	}
	
}
