package com.example.demo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
@CrossOrigin(origins= {"http://localhost:3000" ,"http://localhost:4200"})
@RestController
public class PhoneController {
	
	@Autowired
	private IPhoneServices phoneService;
	
	@GetMapping(value="/IPhone11/list")
	public List<Phone> getPhone(){
		List<Phone> phones=phoneService.findAll();
		return phones;
	}
	
	@GetMapping(value="/IPhone11/{color}/{memory}")
	public String processForm(@PathVariable String color,@PathVariable String memory)
	{
		return String.format("Price of %s iPhone with %s memory is %susd!",color, memory, phoneService.find(color, memory));
	}
	/*
	@RequestMapping(path="/message", produces=MediaType.TEXT_PLAIN_VALUE)
    @ResponseBody
    public String processForm(@RequestParam(required = false) String color, @RequestParam(required = false) String memory)
	{
        return String.format("Price of %s iPhone with %s memory is %susd!",color, memory, phoneService.find(color, memory));
    }*/
}
