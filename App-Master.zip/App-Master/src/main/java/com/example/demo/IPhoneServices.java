package com.example.demo;

import java.util.List;

public interface IPhoneServices {

	List<Phone> findAll();

	String find(String color, String memory);

}
